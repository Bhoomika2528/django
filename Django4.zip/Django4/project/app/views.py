from django.shortcuts import render,redirect
from .models import *
def home(request):
    return render(request,'app/home.html')
def register(request):
    if request.method == 'POST':
        username=request.POST['username']
        password=request.POST['password']
        mobile=request.POST['mobile']
        email=request.POST['email']
        address=request.POST['address']
        Register.objects.create(
            name=username,
            password=password,
            mobile=mobile,
            email=email,
            address=address
        ).save()
        return redirect('login')
    return render(request,'app/register.html')
# Create your views here.
def login(request):
    if request.method == 'POST':
        username=request.POST['username']
        password=request.POST['password']
        
        if Register.objects.filter(name=username,password=password):
            return redirect('home')
        else:
            return redirect('register')
    return render(request,'app/login.html')

def about(request):
    return render(request,'app/about.html')
def certificate(request):
    return render(request,'app/certificate.html')
def contact(request):
    if request.method == 'POST':
        username=request.POST['username']
        mobile=request.POST['mobile']
        email=request.POST['email']
        address=request.POST['address']
        Contact.objects.create(
            name=username,
            mobile=mobile,
            email=email,
            address=address
        ).save()
        return redirect('home')
    return render(request,'app/contact.html')