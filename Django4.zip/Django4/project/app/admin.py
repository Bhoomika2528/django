from django.contrib import admin
from .models import *
admin.site.register(Register)
admin.site.register(Contact)
# Register your models here.
